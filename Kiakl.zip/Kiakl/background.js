function handleMessage(request) {

}

chrome.runtime.onMessage.addListener(handleMessage);